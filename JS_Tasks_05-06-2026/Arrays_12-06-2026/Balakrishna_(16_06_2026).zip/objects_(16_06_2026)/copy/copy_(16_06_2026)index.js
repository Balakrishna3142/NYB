//copying of objects
//:normal copy
//:shallow copy
//:deep copy


//1.normal copy
var obj={a:"one",b:"two",c:"three"}
var obj1=obj
console.log(obj)
console.log(obj1)

obj1.d="four"
console.log(obj1)
console.log(obj

)
 //shallow copy with the help of spredoperater
 var obj2={...obj}
 console.log("obj2".obj2)
 console.log("obj",obj)